// Autenticación de demostración local. Un sitio público con cuentas reales necesita servidor.
(() => {
  'use strict';
  document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const correoInput = document.getElementById('correo');
    const contrasenaInput = document.getElementById('contrasena');
    const togglePassword = document.getElementById('togglePassword');
    const loginMessage = document.getElementById('loginMessage');
    const forgotPassword = document.getElementById('forgotPassword');
    const rememberInput = document.getElementById('recordar');

    const setMessage = (text, success = false) => {
      if (!loginMessage) return;
      loginMessage.textContent = text;
      loginMessage.style.color = success ? '#1F5A5A' : '#B54735';
    };
    const bytesToHex = bytes => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
    const hexToBytes = hex => new Uint8Array((hex.match(/.{1,2}/g) || []).map(byte => parseInt(byte, 16)));
    const newSalt = () => {
      const bytes = new Uint8Array(16);
      window.crypto.getRandomValues(bytes);
      return bytesToHex(bytes);
    };
    const hashPassword = async (password, saltHex) => {
      if (!window.crypto || !window.crypto.subtle) throw new Error('Secure password hashing is unavailable in this browser context.');
      const key = await window.crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
      const bits = await window.crypto.subtle.deriveBits({
        name: 'PBKDF2', salt: hexToBytes(saltHex), iterations: 120000, hash: 'SHA-256'
      }, key, 256);
      return bytesToHex(new Uint8Array(bits));
    };

    if (togglePassword && contrasenaInput) {
      togglePassword.addEventListener('click', () => {
        const visible = contrasenaInput.type === 'password';
        contrasenaInput.type = visible ? 'text' : 'password';
        togglePassword.textContent = visible ? 'Ocultar' : 'Mostrar';
        togglePassword.setAttribute('aria-pressed', String(visible));
      });
    }

    if (loginForm) {
      loginForm.addEventListener('submit', async event => {
        event.preventDefault();
        const correo = correoInput.value.trim().toLowerCase();
        const contrasena = contrasenaInput.value;
        setMessage('');
        if (!correo || !contrasena) return setMessage('Completa todos los campos.');

        const almacenados = window.NEXORA.readJSON('usuariosNexora', []);
        const usuarios = Array.isArray(almacenados) ? almacenados : [];
        const usuario = usuarios.find(item => item && String(item.correo || '').trim().toLowerCase() === correo);
        let credencialesCorrectas = false;
        try {
          if (usuario && usuario.passwordHash && usuario.passwordSalt) {
            credencialesCorrectas = await hashPassword(contrasena, usuario.passwordSalt) === usuario.passwordHash;
          } else if (usuario) {
            credencialesCorrectas = (usuario.password ?? usuario.contrasena) === contrasena;
            if (credencialesCorrectas && window.crypto && window.crypto.subtle) {
              const salt = newSalt();
              usuario.passwordSalt = salt;
              usuario.passwordHash = await hashPassword(contrasena, salt);
              delete usuario.password;
              delete usuario.contrasena;
              const index = usuarios.findIndex(item => item && item.correo === usuario.correo);
              if (index >= 0) usuarios[index] = usuario;
              window.NEXORA.writeJSON('usuariosNexora', usuarios);
            }
          }
        } catch (error) {
          return setMessage('No se pudo verificar la cuenta en este navegador. Abre NEXORA en HTTPS o localhost.');
        }

        const demo = { nombre: 'Usuario Demo', correo: 'demo@nexora.com' };
        const esDemo = correo === 'demo@nexora.com' && contrasena === 'Nexora2026!';
        if (!credencialesCorrectas && !esDemo) return setMessage('Correo o contraseña incorrectos. Verifica tus datos.');

        const usuarioActivo = usuario || demo;
        const sesion = { nombre: usuarioActivo.nombre || 'Usuario NEXORA', correo: usuarioActivo.correo };
        if (!window.NEXORA.saveSession(sesion, Boolean(rememberInput && rememberInput.checked))) {
          return setMessage('No se pudo guardar la sesión. Revisa la configuración de privacidad del navegador.');
        }
        setMessage('¡Bienvenido a NEXORA!', true);
        window.setTimeout(() => { window.location.href = 'dashboard.html'; }, 500);
      });
    }

    if (forgotPassword) {
      forgotPassword.addEventListener('click', event => {
        event.preventDefault();
        const correo = correoInput.value.trim();
        if (!correo) {
          setMessage('Primero escribe tu correo electrónico.');
          correoInput.focus();
          return;
        }
        setMessage('La recuperación por correo no está habilitada en esta demo local.');
      });
    }
  });
})();
