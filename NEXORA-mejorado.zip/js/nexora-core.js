(() => {
  'use strict';

  const safeRead = (store, key, fallback = null) => {
    try {
      const value = store.getItem(key);
      return value === null ? fallback : JSON.parse(value);
    } catch (error) {
      return fallback;
    }
  };

  const getStorage = name => {
    try { return window[name]; } catch (error) { return null; }
  };
  const readFromStorage = (name, key, fallback = null) => {
    try {
      const store = getStorage(name);
      return store ? safeRead(store, key, fallback) : fallback;
    } catch (error) {
      return fallback;
    }
  };
  const readJSON = (key, fallback = null) => readFromStorage('localStorage', key, fallback);
  const writeJSON = (key, value, storeName = 'localStorage') => {
    try {
      const store = getStorage(storeName);
      if (!store) return false;
      store.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      return false;
    }
  };
  const getSession = () => {
    const session = readFromStorage('localStorage', 'sesionNexora', null) ||
      readFromStorage('sessionStorage', 'sesionNexora', null);
    return session && typeof session === 'object' && typeof session.correo === 'string'
      ? session
      : null;
  };
  const saveSession = (session, remember = false) => {
    try {
      window.localStorage.removeItem('sesionNexora');
      window.sessionStorage.removeItem('sesionNexora');
      return writeJSON('sesionNexora', session, remember ? 'localStorage' : 'sessionStorage');
    } catch (error) {
      return false;
    }
  };
  const clearSession = () => {
    try {
      window.localStorage.removeItem('sesionNexora');
      window.sessionStorage.removeItem('sesionNexora');
    } catch (error) {
      // El navegador puede bloquear el almacenamiento; la redirección sigue funcionando.
    }
  };

  window.NEXORA = Object.freeze({ readJSON, writeJSON, getSession, saveSession, clearSession });

  const motionAllowed = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (motionAllowed) document.documentElement.classList.add('js-ready');

  document.addEventListener('DOMContentLoaded', () => {
    const currentPage = (window.location.pathname.split('/').pop() || 'index.html').toLowerCase();
    const moduleLinks = [
      ['dashboard.html', 'Inicio'], ['perfil.html', 'Mi perfil'],
      ['networking.html', 'Networking'], ['publicaciones.html', 'Publicaciones'],
      ['eventos.html', 'Eventos'], ['mensajes.html', 'Mensajes']
    ];
    if (moduleLinks.some(([href]) => href === currentPage)) {
      const header = document.querySelector('body > header:not(.auth-navbar):not(.dashboard-nav)');
      if (header) {
        let nav = header.querySelector('nav');
        if (!nav) {
          nav = document.createElement('nav');
          nav.setAttribute('aria-label', 'Navegación principal');
          header.appendChild(nav);
        }
        nav.setAttribute('aria-label', 'Navegación principal');
        const existing = new Set(Array.from(nav.querySelectorAll('a[href]'), link =>
          (link.getAttribute('href') || '').split(/[?#]/)[0].split('/').pop().toLowerCase()
        ));
        moduleLinks.forEach(([href, label]) => {
          if (existing.has(href)) return;
          const link = document.createElement('a');
          link.href = href;
          link.textContent = label;
          nav.appendChild(link);
        });
      }
    }
    document.querySelectorAll('header nav').forEach(nav => {
      if (!nav.hasAttribute('aria-label')) nav.setAttribute('aria-label', 'Navegación principal');
    });
    document.querySelectorAll('nav a[href]').forEach(link => {
      const href = link.getAttribute('href') || '';
      if (!href || href.startsWith('#') || href.startsWith('mailto:')) return;
      const destination = href.split(/[?#]/)[0].split('/').pop().toLowerCase();
      if (destination === currentPage) {
        link.classList.add('active');
        link.setAttribute('aria-current', 'page');
      }
    });

    document.querySelectorAll('input, select, textarea').forEach(control => {
      if (control.labels && control.labels.length) return;
      if (control.getAttribute('aria-label')) return;
      const placeholder = control.getAttribute('placeholder');
      if (placeholder) control.setAttribute('aria-label', placeholder.replace(/[.…]+$/, ''));
    });

    document.querySelectorAll('#loginMessage, #message, #mensaje').forEach(message => {
      if (!message.hasAttribute('aria-live')) message.setAttribute('aria-live', 'polite');
    });

    if (!motionAllowed) return;
    const selector = '.panel, .card, .side-card, .post, .person-card, .event-card, .feature-card, .profile-header, .chat-container';
    const observer = 'IntersectionObserver' in window
      ? new IntersectionObserver(entries => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              entry.target.classList.add('nx-visible');
              observer.unobserve(entry.target);
            }
          });
        }, { threshold: 0.08, rootMargin: '0px 0px -30px 0px' })
      : null;

    const observeCards = root => {
      if (!(root instanceof Element || root instanceof Document)) return;
      const candidates = [];
      if (root.matches && root.matches(selector)) candidates.push(root);
      candidates.push(...root.querySelectorAll(selector));
      candidates.forEach(card => {
        if (card.classList.contains('nx-reveal')) return;
        card.classList.add('nx-reveal');
        if (observer) observer.observe(card);
        else card.classList.add('nx-visible');
      });
    };
    observeCards(document);
    if ('MutationObserver' in window) {
      new MutationObserver(records => {
        records.forEach(record => record.addedNodes.forEach(node => {
          if (node.nodeType === Node.ELEMENT_NODE) observeCards(node);
        }));
      }).observe(document.body, { childList: true, subtree: true });
    }
  });
})();
