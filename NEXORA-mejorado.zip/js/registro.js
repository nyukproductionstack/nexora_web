// Registro local para prototipo: las cuentas no se sincronizan con un servidor.
(() => {
  'use strict';
  document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('registerForm');
    if (!form) return;
    const message = document.getElementById('message');
    const submit = form.querySelector('[type="submit"]');
    const showMessage = (text, success = false) => {
      message.textContent = text;
      message.style.color = success ? '#1F5A5A' : '#B54735';
    };
    const bytesToHex = bytes => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
    const hashPassword = async (password, salt) => {
      if (!window.crypto || !window.crypto.subtle) throw new Error('Secure password hashing is unavailable.');
      const key = await window.crypto.subtle.importKey(
        'raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']
      );
      const bits = await window.crypto.subtle.deriveBits({
        name: 'PBKDF2', salt, iterations: 120000, hash: 'SHA-256'
      }, key, 256);
      return bytesToHex(new Uint8Array(bits));
    };

    form.addEventListener('submit', async event => {
      event.preventDefault();
      const nombre = document.getElementById('nombre').value.trim();
      const correo = document.getElementById('correo').value.trim().toLowerCase();
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirmPassword').value;
      showMessage('');
      if (nombre.length < 3) return showMessage('Ingresa un nombre válido.');
      if (password.length < 8) return showMessage('La contraseña debe tener al menos 8 caracteres.');
      if (password !== confirmPassword) return showMessage('Las contraseñas no coinciden.');

      const stored = window.NEXORA.readJSON('usuariosNexora', []);
      if (!Array.isArray(stored)) return showMessage('No se pudieron leer las cuentas guardadas.');
      if (stored.some(user => user && String(user.correo || '').toLowerCase() === correo)) {
        return showMessage('Este correo ya está registrado.');
      }

      if (submit) submit.disabled = true;
      try {
        const salt = new Uint8Array(16);
        window.crypto.getRandomValues(salt);
        const passwordHash = await hashPassword(password, salt);
        const nuevoUsuario = {
          nombre,
          correo,
          passwordSalt: bytesToHex(salt),
          passwordHash
        };
        if (!window.NEXORA.writeJSON('usuariosNexora', [...stored, nuevoUsuario])) {
          showMessage('No se pudo guardar la cuenta. Revisa el espacio disponible del navegador.');
          return;
        }
        showMessage('¡Cuenta creada correctamente!', true);
        window.setTimeout(() => { window.location.href = 'login.html'; }, 700);
      } catch (error) {
        showMessage('No se pudo proteger la contraseña en este navegador. Abre NEXORA en HTTPS o localhost.');
      } finally {
        if (submit) submit.disabled = false;
      }
    });
  });
})();
